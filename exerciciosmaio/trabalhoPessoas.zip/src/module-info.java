/**
 * 
 */
/**
 * @author User
 *
 */
module java05 {
}