package exercicios1906;

public class Ex36 {

	public static void main(String[] args) {
		double[] A = new double[11];
		for(int a=0; a<A.length; a++) {
			A[a] = Math.pow(2, a);
			System.out.println(A[a]);	
			
		}
	}

}
